import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Scanner;

public class Main {

    /**
     * Returns the length of the longest well-formed parentheses substring.
     *
     * Time complexity: O(n)
     * Space complexity: O(n)
     */
    public static int longestValidParentheses(String s) {
        Deque<Integer> stack = new ArrayDeque<>();
        stack.push(-1); // Base index before the start of a valid substring.

        int maxLength = 0;

        for (int i = 0; i < s.length(); i++) {
            char current = s.charAt(i);

            if (current == '(') {
                stack.push(i);
            } else {
                stack.pop();

                if (stack.isEmpty()) {
                    // This ')' cannot be matched. Use it as the new boundary.
                    stack.push(i);
                } else {
                    // The valid substring ends at i and starts after the stack top.
                    maxLength = Math.max(maxLength, i - stack.peek());
                }
            }
        }

        return maxLength;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String s = scanner.hasNextLine() ? scanner.nextLine() : "";
        System.out.println(longestValidParentheses(s));
        scanner.close();
    }
}
