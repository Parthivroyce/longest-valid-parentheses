# Longest Valid Parentheses

A Java solution to the **Longest Valid Parentheses** problem.

## Problem

Given a string containing only `(` and `)`, return the length of the longest contiguous substring that forms a valid (well-formed) parentheses sequence.

### Examples

| Input | Output | Explanation |
|---|---:|---|
| `(()` | `2` | The longest valid substring is `()` |
| `)()())` | `4` | The longest valid substring is `()()` |
| `` (empty string) `` | `0` | No valid substring exists |

## Approach: Stack of indices

The solution uses a stack to store character indices rather than the characters themselves.

1. Start with `-1` on the stack. This acts as the boundary immediately before a possible valid substring.
2. For an opening parenthesis `(`, push its index.
3. For a closing parenthesis `)`:
   - Pop the stack to match an opening parenthesis.
   - If the stack becomes empty, push the current index. It is now the boundary after an unmatched closing parenthesis.
   - Otherwise, calculate the current valid substring length as `currentIndex - stack.peek()` and update the maximum.
4. Return the maximum length found.

The boundary index ensures that the calculated length is contiguous and excludes unmatched parentheses.

## Complexity

- **Time:** `O(n)` — each character is processed once, with at most one push and one pop.
- **Space:** `O(n)` — in the worst case, the stack stores indices for all opening parentheses.

## Requirements

- Java 8 or later
- No external libraries or dependencies

## Run

Compile:

```bash
javac Main.java
```

Run:

```bash
java Main
```

Enter one parentheses string and press Enter. The program prints the length.

Example:

```text
)()())
4
```

For an empty input line, the program prints `0`.

## Additional cases to verify

| Input | Expected output |
|---|---:|
| `""` (empty line) | `0` |
| `(` | `0` |
| `)` | `0` |
| `()` | `2` |
| `()()` | `4` |
| `(()` | `2` |
| `)()())` | `4` |
| `()(())` | `6` |
| `((()))` | `6` |
| `())((())` | `4` |

## Correctness intuition

At every closing parenthesis, the stack top represents the index immediately before the longest valid suffix ending at the current position. If no unmatched opening parenthesis remains, the current closing parenthesis becomes a new invalid boundary. Otherwise, subtracting the boundary index from the current index gives the length of a valid contiguous suffix. Taking the maximum over all closing positions therefore returns the longest valid parentheses substring.
